// Derick Bui
// assn1.cpp
// This program demonstrates the use of char dynamic array, pointers, memory allocation, and removing and inserting elements in a FIFO order

#include <iostream>
#include <string.h>
#include <cstdlib>
using namespace std;

//This method searches the word you typedWord
//@param typedWord the user inputed char*
//@param recent_list[] Lines from the recent list
//@param library_list[] Lines from the library list
//@param recRandSize[] List of allocated memories from recent list
//@param libRandSize[] List of allocated memories from library list
//@param letters[] List of letters for new lines in library
void searchWord(char* typedWord, char* recent_list[], char* library_list[], int recRandSize[], int libRandSize[], const char letters[], const int letterCount[], const char* words[]) {
  srand(time(NULL));
  int docEjected = 0;
  int recentSize = 128;
  for (int i = 0; i < recentSize; i++) { //go through the recent_list
    bool flag = false;

    int typedCounter = 0;
    while (!(!typedWord[typedCounter])) { //count size of the input
      typedCounter++;
    }
    
    for (int j = 0; j < recRandSize[i] - 2; j++) { //search the word the user typed in
      bool found = true;
      for (int k = 0; k < typedCounter; k++) {
        if ((j + k) < recRandSize[i]) {
          if (typedWord[k] != recent_list[i][j + k]) {
            found = false;
          }
        }
      }
      if (found == true) {
        flag = true;
      }
    }

    if (flag == false) { //if word does not exist in line, purge the line
        char* temp = recent_list[i]; //for not losing the reference
        int tempInt = recRandSize[i];

        for (int j = i; j < 127; j++) { //change pointers for both recent_list and recRandSize
          recent_list[j] = recent_list[j+1];
          recRandSize[j] = recRandSize[j+1];
        }

        recent_list[127] = library_list[0]; //pointer from bottom of recent_list goes to top of library_list
        recRandSize[127] = libRandSize[0];

        for (int j = 0; j < 1023; j++) {
          library_list[j] = library_list[j+1];
          libRandSize[j] = libRandSize[j+1];
        }
        
        delete [] temp; //delete old line
        temp = NULL;
        temp = new char[tempInt]; //initialize new line with same memory size
        int wordStopper = rand() % 14;
        for (int j = 0; j < tempInt; j++) {
          int randNum2 = rand() % 14; //for words
          while (wordStopper == randNum2) {
            randNum2 = rand() % 14;
          }
          char* oneWord = new char[letterCount[randNum2]];
          for (int k = 0; k < letterCount[randNum2]; k++) {
            oneWord[k] = words[randNum2][k];
          } 
          for (int k = 0; k < letterCount[randNum2]; k++) {
            if (j < tempInt) {
              temp[j] = oneWord[k];
              j++;
            }
          }
      
          delete [] oneWord;
          oneWord = NULL;
        }
        

        library_list[1023] = temp; //new line goes last on library_list
        libRandSize[1023] = tempInt; //size goes last on libRandSize

        docEjected++;
        recentSize--;
        i--;
    }
  }
  cout << typedWord << ": " << docEjected << " documents ejected and reinitialized" << endl;
}

//This executes the program
int main() {

  srand(time(NULL));

	//26 letters
	const char letters[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

	//14 words
	const char* words[] = {"FIRST", "CPP", "REVIEW", "ASSIGNMENT", "CECS", "BEACH", "ECS", "FALL", "SPRING", "OS", "MAC", "LINUX", "WINDOWS", "LAB"};

  //Letter count of words
  const int letterCount[] = {5,3,6,10,4,5,3,4,6,2,3,5,7,3};

	//Array of char pointers
	char* recent_list[128];
	char* library_list[1024];

  //for storing random memory size
	int recRandSize[128];
	int libRandSize[1024];

  //Generate recent list
  for (int i = 0; i < 128; i++) {
    int randomN3 = 2000000 + (rand() % 1000000 + 1); //for allocating space for 2-3 kb per line
    recRandSize[i] = randomN3; //stores size of word
    int dividedNum = (randomN3 / 10);
    int wordStopper = rand() % 14; //index of word that is not going to be generated in line

    char* line = new char[randomN3];
    for (int j = 0; j < randomN3; j++) {
      int randNum2 = rand() % 14; //for words
      while (wordStopper == randNum2) { //prevent one word to be in the line
        randNum2 = rand() % 14;
      }
      char* oneWord = new char[letterCount[randNum2]];
      for (int k = 0; k < letterCount[randNum2]; k++) {
        oneWord[k] = words[randNum2][k];
      } 
      for (int k = 0; k < letterCount[randNum2]; k++) {
        if (j < randomN3) {
          line[j] = oneWord[k];
          j++;
        }
      }

      delete [] oneWord;
      oneWord = NULL;
    }

    recent_list[i] = line;
  }

//Generate library
  for (int i = 0; i < 1024; i++) {
    int randomN3 = 2000000 + (rand() % 1000000 + 1); //for allocating space for 2-3 kb per line
    libRandSize[i] = randomN3; //store size of word
    int wordStopper = rand() % 14; //index of word that is not going to be generated in line

    char* line = new char[randomN3];
    for (int j = 0; j < randomN3; j++) {
      int randNum2 = rand() % 14; //for words
      while (wordStopper == randNum2) { //prevent one word to be in the line
        randNum2 = rand() % 14;
      }
      char* oneWord = new char[letterCount[randNum2]];
      for (int k = 0; k < letterCount[randNum2]; k++) {
        oneWord[k] = words[randNum2][k];
      } 
      for (int k = 0; k < letterCount[randNum2]; k++) {
        if (j < randomN3) {
          line[j] = oneWord[k];
          j++;
        }
      }

      delete [] oneWord;
      oneWord = NULL;
    }

      library_list[i] = line;
  }

  char* userInput = new char[10];
  cout << "Press '1' to find word" << endl;
  cout << "Press 'q' to quit" << endl;
  cout << "Enter your choice: ";
  cin.getline(userInput, 10);
  while (userInput[0] != 'q') {
    if (userInput[0] == '1') {
      char* typedWord = new char[20];
      cout << "What word are you looking for?: ";
      cin.getline(typedWord, 20);
      searchWord(typedWord, recent_list, library_list, recRandSize, libRandSize, letters, letterCount, words);
      delete [] typedWord;
    }

    cout << "Press '1' to find word" << endl;
    cout << "Enter '1' or 'q': " ;
    cin.getline(userInput, 20);
  }
  return 0;
}