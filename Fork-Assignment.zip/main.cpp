#include <unistd.h>
#include <sys/wait.h>
#include <iostream>
#include <cstdlib>
using namespace std;

int main() {

  //26 Letters, indexes 0 - 25
  char letter[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

  bool flag = true; //looping choice menu
  long childPID;
  int choice; //for choosing choices
  int size; //length of random letters array
  char letterChoice; //letter to search for
  int letterCount; //How many letters appear in the search

  cout << "Parent Process " << getpid() << "starts." << endl;
  cout << "Type in length of array: "; //for size of char array
  cin >> size; //input size of char array

  while (flag) {
    cout << "1. Run Process" << endl;
    cout << "2. Exit Program" << endl;
    cout << "Enter ";
    cin >> choice;

    if (choice == 1) { //process starts
      childPID = fork();
      if (childPID > 0) {
        wait(NULL);
        cout << "Child Process complete" << endl;
      }
      else if (childPID == 0) { //child process
        char randLetter[size]; //initialize array

        srand(0); //Seeding random

        for (int i = 0; i < size; i++) { //fill array with random letters
          randLetter[i] = letter[rand() % 26];
        }

        cout << "Letter to look for: ";
        cin >> letterChoice;

        letterCount = 0;
        for (int i = 0; i < size; i++) {
          if (letterChoice == randLetter[i]) {
            letterCount++;
          }
        }
        cout << "There are " << letterCount << " letters in the array." << endl;
        exit(0);
      }
    }
    else if (choice == 2) { //exit program
      flag = false;
    }
    else {
      cout << "Not a valid input" << endl;
    }
  }
  exit(0);
}